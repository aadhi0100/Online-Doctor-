from flask import Flask, render_template, request, redirect, session, url_for, jsonify
from models import db, Patient, Doctor, MedicationQuery
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        if Patient.query.filter_by(username=username).first():
            return "User already exists"
        new_user = Patient(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = Patient.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('dashboard'))
        return "Invalid credentials"
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    doctors = Doctor.query.all()
    return render_template('dashboard.html', doctors=doctors)

@app.route('/ask', methods=['GET', 'POST'])
def ask():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        question = request.form['question']
        query = MedicationQuery(patient_id=session['user_id'], question=question, response="Pending")
        db.session.add(query)
        db.session.commit()
        return "Question submitted!"
    return render_template('ask_medication.html')

@app.route('/doctor_login', methods=['GET', 'POST'])
def doctor_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        doctor = Doctor.query.filter_by(username=username).first()
        if doctor and check_password_hash(doctor.password, password):
            session['doctor_id'] = doctor.id
            return redirect(url_for('doctor_dashboard'))
        return "Invalid credentials"
    return render_template('doctor_login.html')

@app.route('/doctor_dashboard')
def doctor_dashboard():
    if 'doctor_id' not in session:
        return redirect(url_for('doctor_login'))
    queries = MedicationQuery.query.all()
    return render_template('doctor_dashboard.html', queries=queries)

@app.route('/respond/<int:query_id>', methods=['POST'])
def respond(query_id):
    if 'doctor_id' not in session:
        return redirect(url_for('doctor_login'))
    response_text = request.form['response']
    query = MedicationQuery.query.get(query_id)
    query.response = response_text
    db.session.commit()
    return redirect(url_for('doctor_dashboard'))

@app.route('/api/doctors')
def api_doctors():
    doctors = Doctor.query.all()
    return jsonify([{
        "name": d.name,
        "designation": d.designation,
        "degree": d.degree
    } for d in doctors])

@app.route('/api/ask', methods=['POST'])
def api_ask():
    data = request.json
    new_q = MedicationQuery(patient_id=data['patient_id'], question=data['question'])
    db.session.add(new_q)
    db.session.commit()
    return jsonify({"message": "Submitted"}), 201

if __name__ == '__main__':
    app.run(debug=True)
